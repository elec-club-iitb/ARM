#include <lpc214x.h>
#include <math.h>
//sample library development
#include "pll.h"
pll clock(12000000,6,1);
#include "uart.h"
#include "spi.h"
#include "delay.h"
#include "pin.h"
#include "ILI9225.h"
int main()
{
	uart0 serial(clock.getPeripheralClock(),9600);
	#define D(x) serial.printString(x)

	pin rst(124),rs(8),cs(7),led(9);
	spi1 s(clock.getPeripheralClock(),16);;
	ILI9225 lcd(&s,rst,rs,cs,led);		
			delay wait(clock.getCpuClock());
	
//pin rst(124),rs(8),cs(20),sdi(19),clk(17),led(9);
//ILI9225 lcd(rst,rs,cs,sdi,clk,led);
	
	
	
	lcd.begin(clock.getCpuClock());	D("lcd initialised");
	lcd.clear();				D("Clearing LCD");
	unsigned int i=50;
	char str[]="Hello Universe";
	int p=1;
	lcd.setFont(Terminal11x16);
	while (1)
	{
	//	for(int x=1;x<=ILI9225_LCD_WIDTH;x++)
	//	for(int y=1;y<=ILI9225_LCD_HEIGHT;y++)
//		lcd.drawPixel(x,y,sqrt(float(p*x*sin(1.0*x*y)+y*y))*20*p);
		//wait.s(1);
		i++;
		lcd.drawText(0,0,"HELLO UNIVERSE ! ",65535-i);
		lcd._setWindow(0,0,ILI9225_LCD_WIDTH,ILI9225_LCD_HEIGHT);
		for(int y=0;y<ILI9225_LCD_HEIGHT;y++)
		for(int x=0;x<ILI9225_LCD_WIDTH;x++)
		{lcd._writeData((x-i)*(y-i));
			//wait.ms(10);
		}
		//wait.s(1);
		p++;
		
		
		
	}
} 

