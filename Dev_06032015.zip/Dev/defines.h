
//definations for user compatibity
#ifndef DEFINES_H
	#define DEFINES_H
typedef unsigned char byte;
#endif
