//spi library
#include "spi.h"
//Initialise spi pins on  P0.4
spi0::spi0()
{
}
void spi0::initPins(void)
{
	PINSEL0=(PINSEL0&0xFFFF00FF)|0x00001500;
	//  PINSEL0 = (PINSEL0 & ~(3 << 12)) | (1 << 12); //  MOSI0 SPI0
  //   PINSEL0 = (PINSEL0 & ~(3 << 10)) | (1 << 10); //  MISO0 SPI0
  //   PINSEL0 = (PINSEL0 & ~(3 << 8))  | (1 << 8);  //  SCK0  SPI0
}

//Set constructor 
spi0::spi0(unsigned long pclk,int _dataLength,int _clkDiv)
{
	clock=pclk/_clkDiv;			//save for clock
	dataLength=_dataLength;	
	clkDiv=_clkDiv;
	initPins();		//initialse pins
	setClockDiv(clkDiv);		//initialise clock
	S0SPCR=(0xF00&(dataLength<<8))|(1<<5)|(0<<4)|(0<<3)|(1<<2);	//initialse control register
	S0SPDR=0;
}
	
void spi0::setClockDiv(int factor)
{
	clkDiv=factor;		//save 
	S0SPCCR=clkDiv;
}
void spi0::setDataLength(int len)
{
	dataLength=len; 	//save a new copy
	S0SPCR= (S0SPCR&(~0xF00))|(len<<8);
}

int spi0::rw(int data)
{
	
	S0SPDR=data;
	while(!(S0SPSR&0x80));
	int dummy =S0SPDR;
	return dummy;
}
void spi0::w(int data)
{	
	S0SPDR=data;
	while(!(S0SPSR&0x80));
}
